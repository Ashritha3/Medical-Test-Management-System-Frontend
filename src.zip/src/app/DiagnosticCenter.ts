export class DiagnosticCenter
{
    public centerId:number;	
	public centerName:string;
	public tests=[];
	public appointments=[];

	constructor(){
		
	}
}