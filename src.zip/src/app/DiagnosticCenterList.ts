import { DiagnosticCenter } from './DiagnosticCenter';


export class DiagnosticCenterList
{
    public centerList:DiagnosticCenter[];
}