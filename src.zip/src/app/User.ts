export class User
{
    public userId:number;
	public userName:string;
	public userPassword:string;
	public contactNumber:number;
	public userEmail:string;
	public userRole:string;
	public age:number;
	public gender:string;

	constructor(){}
}