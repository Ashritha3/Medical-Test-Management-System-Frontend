import { DiagnosticTest } from './DiagnosticTest';

export class DiagnosticTestList
{
    public testList:DiagnosticTest[];
}