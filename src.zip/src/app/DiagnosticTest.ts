export class DiagnosticTest
{
    public testId:number;
    public testName:string;
}