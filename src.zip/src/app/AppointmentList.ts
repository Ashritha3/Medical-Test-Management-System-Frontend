import { Appointment } from './Appointment';

export class AppointmentList
{
    public appointmentList:Appointment[];
}