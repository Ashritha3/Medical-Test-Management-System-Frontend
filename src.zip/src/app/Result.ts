export interface Result {
    sliderArray: [
      {'img': string, 'alt': string}
    ];
  }
  